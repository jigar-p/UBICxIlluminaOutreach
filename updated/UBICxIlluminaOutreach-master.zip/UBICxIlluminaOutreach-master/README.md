# UBIC x Illumina Outreach

A project done by students at UCSD to teach and inspire next generation students about Biology and Computer Science. This is a collaboration between the Undergraduate Bioinformatics Club and illumina.
